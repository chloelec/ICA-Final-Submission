"""Portable clustering utilities. Analytical choices are shown in notebook 01."""
from pathlib import Path
import numpy as np
import pandas as pd
import openpyxl

def load_companies(root):
    membership=pd.read_csv(root/'config/custom_groups.csv')
    wb=openpyxl.load_workbook(root/'data/raw/ICA_Final_dataset.xlsx',read_only=True,data_only=True)
    try:
        ws=wb['Cluster dataset'];headers={str(c.value).strip():c.column-1 for c in ws[4] if c.value}
        fields={'Product categories':'prod_cat','Value-chain coverage':'vcc','GENAI Importance':'genai_importance','Pricing model':'pricing_model'}
        records=[]
        for row_number,row in enumerate(ws.iter_rows(min_row=6,values_only=True),6):
            firm=str(row[0] or '').strip()
            if firm not in set(membership.firm):continue
            record={'firm':firm,'workbook_row':row_number}
            for heading,key in fields.items():
                value=row[headers[heading]]
                record[key]=value.strip() if isinstance(value,str) else value
            records.append(record)
    finally:wb.close()
    data=pd.DataFrame(records).merge(membership,on='firm',validate='one_to_one')
    assert len(data)==data.firm.nunique()==22
    assert data[list(fields.values())].notna().all().all()
    assert data.genai_importance.isin([0,1,2]).all()
    assert data.groupby('cluster').size().to_dict()=={1:8,2:6,3:8}
    return data

def independent_silhouettes(distance, labels):
    labels=np.asarray(labels);rows=[]
    for i,label in enumerate(labels):
        own=(labels==label)&(np.arange(len(labels))!=i)
        a=distance[i,own].mean()
        alternatives={int(c):float(distance[i,labels==c].mean()) for c in set(labels) if c!=label}
        closest=min(alternatives,key=alternatives.get);b=alternatives[closest]
        rows.append({'a':a,'b':b,'nearest_other_group':closest,'silhouette':(b-a)/max(a,b) if max(a,b) else 0.})
    return pd.DataFrame(rows)

def group_profiles(data, labels):
    d=data.assign(group=np.asarray(labels));out=[]
    for label,g in d.groupby('group'):
        out.append(dict(group=label,n=len(g),members='; '.join(g.display_name),product_breadth=g.prod_cat.mean(),value_chain=g.vcc.mean(),genai_importance=g.genai_importance.mean(),pricing='; '.join(f'{k}: {v}' for k,v in g.pricing_model.value_counts().items())))
    return pd.DataFrame(out)
