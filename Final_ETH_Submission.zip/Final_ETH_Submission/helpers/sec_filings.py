"""SEC filing extraction, dictionary tagging and summary rates for notebook 03.

Consolidated from ica_filings/schema.py, terms.py, extract.py and tag.py.
The extraction rules, dictionaries and rate calculations are preserved.
"""
import csv
import os
import re
import sys
import warnings

from bs4 import XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

from dataclasses import dataclass, asdict

# One row = one paragraph of one section of one filing.
COLUMNS = [
    "firm",            # canonical name, see FIRMS
    "fiscal_year",     # int, the company's own fiscal year label (see FY_END_MONTH)
    "period",          # "pre" (2019) or "post" (2025)
    "filing_type",     # "10-K" or "20-F"
    "section",         # "business" | "risk_factors" | "mdna"
    "paragraph_id",    # "<firm>_<fy>_<section>_<0001>", unique
    "text",            # cleaned paragraph
    "word_count",      # int; use for per-1,000-word normalisation
    "source_file",     # raw file name in data/raw
    "source_url",      # EDGAR URL (fill in by hand, for the dataset card)
]

# Fiscal-year end month (state this on the dataset card; Adobe FY ends early Dec, others differ).
FY_END_MONTH = {"Adobe": "Nov/Dec (Fri nearest Nov 30)", "Microsoft": "June",
                "Alibaba": "March", "Figma": "December"}
FIRMS = list(FY_END_MONTH)

# Canonical section keys per form.
SECTIONS = {"10-K": ["business", "risk_factors", "mdna"],
            "20-F": ["business", "risk_factors", "mdna"]}

PERIOD_BY_YEAR = {2019: "pre", 2025: "post"}

@dataclass
class Row:
    firm: str; fiscal_year: int; period: str; filing_type: str; section: str
    paragraph_id: str; text: str; word_count: int; source_file: str; source_url: str = ""
    def as_dict(self): return asdict(self)

# Dictionary definitions
FORCES = {
 "entry": [r"barriers? to entry", r"new (market )?entrants?", r"new competitors", r"entry of new", r"enter(ing)? (these|our|the) markets?",
           r"cloud-native", r"AI[- ]native", r"open[- ]weights?", r"open[- ]source (AI|model)", r"low(er)? cost of entry"],
 "rivalry": [r"intense(ly)? compet", r"price cutting", r"competitors? (may|have|could|are)", r"compet(e|es|ing) with", r"market share",
             r"compet(ition|itive) (pressure|landscape)", r"\b(Apple|Autodesk|Corel|Avid|Canva|Figma|Affinity|OpenAI|Midjourney|Stability|Salesforce)\b"],
 "substitutes": [r"substitut", r"free of charge", r"\bfree\b", r"freemium", r"limited functionality", r"(lower|low)[- ]cost (alternatives?|products?|solutions?|tools?|offerings?)", r"alternative (solutions|products|tools|services)",
                 r"built-in (media )?editing", r"social (media|networking) (platforms?|apps?|sites?|networks?)", r"consumer-focused", r"chatbots?", r"AI-first", r"productivity tools",
                 r"migrate from personal computers", r"mobile devices"],
 "buyers": [r"switching costs?", r"price[- ]sensitiv", r"downward pressure", r"pricing pressure", r"renewal", r"churn", r"cancel(l?ation)? of (their )?(subscriptions?|contracts?|plans?)", r"terminate their subscriptions?", r"discount",
            r"customers have more choices", r"pricing (model|structure|strategy)", r"generative credits"],
 "suppliers": [r"third-party (AI )?(service providers?|models?|hosting|cloud|ai\b|technolog)", r"hosting", r"cloud (infrastructure|service providers?)",
               r"data cent(er|re)s?", r"training data", r"\bGPUs?\b", r"\bsuppliers?\b", r"(rely|relies|reliant|dependent) (up)?on third",
               r"licensed content", r"partner models?", r"access(ing)? (to )?(AI |third-party )?(models|datasets|hardware|compute)"],
}
# Topic flags (relevance filter)
GENAI = [r"generative", r"\bgen ?AI\b", r"firefly", r"large language models?", r"foundation models?", r"diffusion", r"text-to-(image|video)",
         r"agentic", r"\bAI models?\b", r"\bLLMs?\b", r"copilot"]
AI_ANY = GENAI + [r"\bAI\b", r"artificial intelligence", r"machine learning", r"sensei"]
CREATIVE = [r"creative", r"\bdesign(ers?|s)?\b", r"photo(shop|graph)", r"\bvideo\b", r"\bimages?\b", r"illustrat", r"premiere", r"content creat", r"express\b",
            r"stock (content|images|photos)", r"copyright", r"\bcontent credentials?\b"]
# Placebo topics: should NOT change because of GenAI
PLACEBO = {"cloud": [r"\bcloud\b"], "mobile": [r"\bmobile\b", r"\btablets?\b", r"smartphones?"]}
SECTIONS_USED = ["business", "risk_factors"]   # MD&A is financial; add back deliberately if wanted

# Supplier matches also require dependency wording in the same sentence segment.
REQUIRE = {"suppliers": [r"\brel(y|ies|iant|iance)\b", r"depend", r"disrupt", r"interrupt", r"unavailab", r"terminat", r"outage", r"prevent", r"interfere",
                         r"limit (or [a-z]+ )?(our|the) ability", r"increase[sd]? (in )?(cost|price)", r"higher (cost|price)", r"sole source", r"challenges accessing"]}

# Filing extraction
DASH = r"[\.\:\-–—\s]*"
# (start_pattern, end_pattern) per form and section. Matched at the start of a line, case-insensitive.
PATTERNS = {
 "10-K": {
  "business":     (rf"item\s*1{DASH}business\b",                      rf"item\s*1a{DASH}risk\s+factors"),
  "risk_factors": (rf"item\s*1a{DASH}risk\s+factors",                 rf"item\s*1b{DASH}unresolved|item\s*2{DASH}properties"),
  "mdna":         (rf"item\s*7{DASH}management.s\s+discussion",       rf"item\s*7a{DASH}quantitative|item\s*8{DASH}(consolidated\s+)?financial"),
 },
 "20-F": {
  "business":     (rf"(item\s*4{DASH})?b{DASH}business\s+overview",   rf"c{DASH}organi[sz]ational\s+structure|item\s*4a"),
  "risk_factors": (rf"(item\s*3{DASH})?d{DASH}risk\s+factors",        rf"item\s*4{DASH}information\s+on\s+the\s+company"),
  "mdna":         (rf"item\s*5{DASH}operating\s+and\s+financial",     rf"item\s*6{DASH}directors"),
 },
}
MIN_WORDS = {"business": 800, "risk_factors": 800, "mdna": 800}   # a real section is longer than a TOC line
BULLET = re.compile(r"^[\u2022\u00b7\u25aa\u2023\-\*]\s*")
DROP = re.compile(r"^Investors and others should note that we announce material", re.I)   # boilerplate, not content
BOILER = re.compile(r"^(table of contents|page \d+|\d{1,3})$", re.I)

def html_to_lines(raw: str) -> list:
    """Return one string per block-level element (handles HTML and plain text)."""
    if "<html" in raw[:5000].lower() or "<div" in raw[:20000].lower() or "<p" in raw[:20000].lower():
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw, "lxml")
        for t in soup(["script", "style", "table"]):   # tables = financial numbers, not prose
            t.decompose()
        for br in soup.find_all("br"): br.replace_with("\n")
        blocks = []
        for el in soup.find_all(["p", "div", "li", "h1", "h2", "h3", "h4", "span"]):
            if el.name in ("span",) and el.find_parent(["p", "div", "li"]): continue
            if el.name == "div" and el.find(["p", "div", "li"]): continue
            blocks.append(el.get_text(" "))
        text = "\n\n".join(clean(b) for b in blocks) if blocks else soup.get_text("\n")
    else:
        text = raw
    return text.split("\n")

def clean(s: str) -> str:
    s = s.replace("\xa0", " ").replace("’", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip()

def extract_section(lines: list, form: str, section: str):
    """Pick the (start, end) pair enclosing the most words -> skips the table of contents."""
    sp, ep = PATTERNS[form][section]
    s_re, e_re = re.compile(rf"^\s*(?:{sp})", re.I), re.compile(rf"^\s*(?:{ep})", re.I)
    cl = [clean(l) for l in lines]
    starts = [i for i, l in enumerate(cl) if s_re.match(l)]
    ends = [i for i, l in enumerate(cl) if e_re.match(l)]
    best, best_w = None, 0
    for s in starts:
        e = next((x for x in ends if x > s), None)
        if e is None: continue
        w = sum(len(l.split()) for l in cl[s + 1:e])
        if w > best_w: best, best_w = (s, e), w
    if not best or best_w < MIN_WORDS[section]: return None
    return cl[best[0] + 1:best[1]]

def to_paragraphs(block: list, min_words: int = 12) -> list:
    """Merge broken lines, drop headers/page numbers, keep paragraphs of >= min_words."""
    paras, buf = [], []
    for l in block:
        if not l or BOILER.match(l):
            if buf: paras.append(" ".join(buf)); buf = []
        else: buf.append(l)
    if buf: paras.append(" ".join(buf))
    merged = []
    for p in paras:   # bullet lists belong to the sentence that introduces them
        if BULLET.match(p) and merged:
            merged[-1] += " " + p
        else:
            merged.append(p)
    return [p for p in merged if len(p.split()) >= min_words and not DROP.search(p)]

def build_rows(path: str, firm: str, fy: int, form: str, url: str = "") -> list:
    raw = open(path, encoding="utf-8", errors="ignore").read()
    lines = html_to_lines(raw)
    rows = []
    for sec in PATTERNS[form]:
        block = extract_section(lines, form, sec)
        if block is None:
            print(f"WARNING {firm} {fy} {form}: section '{sec}' not found -> check by hand", file=sys.stderr)
            continue
        for n, p in enumerate(to_paragraphs(block), 1):
            rows.append(Row(firm, fy, PERIOD_BY_YEAR.get(fy, "other"), form, sec,
                            f"{firm}_{fy}_{sec}_{n:04d}", p, len(p.split()),
                            os.path.basename(path), url).as_dict())
    return rows

# Tagging and summary rates
comp = lambda pats: re.compile("|".join(f"(?:{p})" for p in pats), re.I)
FORCE_RE = {k: comp(v) for k, v in FORCES.items()}
REQ = {k: comp(v) for k, v in REQUIRE.items()}
GEN, AI, CRE = comp(GENAI), comp(AI_ANY), comp(CREATIVE)
PLA = {k: comp(v) for k, v in PLACEBO.items()}

# like-for-like view = risk factors only (Adobe restructured Item 1 between 2019 and 2025)
VIEWS = {"risk_factors": ["risk_factors"], "business+risk": ["business", "risk_factors"]}

SENT = re.compile(r"(?<=[.;:])\s+(?=[A-Z\u2022])")

def tag(rows):
    for r in rows:
        t = r["text"]
        sents = SENT.split(t)   # tag SENTENCES: risk-factor paragraphs can be 400 words and mix several topics
        for k, rx in FORCE_RE.items():
            r[f"hits_{k}"] = sum(1 for x in sents if rx.search(x) and (k not in REQ or REQ[k].search(x)))
        r["genai"] = int(bool(GEN.search(t))); r["ai_any"] = int(bool(AI.search(t))); r["creative"] = int(bool(CRE.search(t)))
        for k, rx in PLA.items(): r[f"hits_placebo_{k}"] = len(rx.findall(t))
        r["forces"] = ",".join(k for k in FORCE_RE if r[f"hits_{k}"])
    return rows

def summarise(rows):
    out = []
    keys = sorted({(r["firm"], r["fiscal_year"], v) for r in rows for v in VIEWS})
    for firm, fy, view in keys:
        sub = [r for r in rows if r["firm"] == firm and r["fiscal_year"] == fy and r["section"] in VIEWS[view]]
        words = sum(int(r["word_count"]) for r in sub)
        row = {"firm": firm, "fiscal_year": fy, "view": view, "words": words, "paragraphs": len(sub)}
        for k in list(FORCE_RE) + [f"placebo_{k}" for k in PLA]:
            row[f"{k}_sentences_per_1000w"] = round(1000 * sum(r[f"hits_{k}"] for r in sub) / words, 2)
        for k in FORCE_RE:   # share of paragraphs touched, and same restricted to genAI/creative paragraphs
            row[f"{k}_paras"] = sum(1 for r in sub if r[f"hits_{k}"])
        row["genai_paras"] = sum(r["genai"] for r in sub); row["ai_any_paras"] = sum(r["ai_any"] for r in sub)
        row["genai_paras_per_1000w"] = round(1000 * row["genai_paras"] / words, 2)
        out.append(row)
    return out

def write(rows, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter=";"); w.writeheader(); w.writerows(rows)
