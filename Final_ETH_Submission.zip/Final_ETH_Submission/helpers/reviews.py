"""Portable review parsing, evidence extraction and optional pinned inference.
Inputs and validation records are included under data/ in this submission.
No dependency on the original ICA directory; no inference is run on import.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, date
from typing import Any
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import hashlib, json, re, os, time
import numpy as np
import pandas as pd
import yaml

ROOT=Path(__file__).resolve().parents[1]
MODEL_ID='cardiffnlp/twitter-roberta-base-sentiment-latest'
REVISION='3216a57f2a0d9c45a2e6c20157c20c49fb4bf9c7'
CLASSES=['Negative','Neutral','Positive']
def load_settings():
    return yaml.safe_load((ROOT/'config/settings.yaml').read_text())
def load_products():
    return yaml.safe_load((ROOT/'config/products.yaml').read_text())['products']
def today_iso():
    return date.today().isoformat()
def stable_hash(*parts: Any, length: int = 16) -> str:
    raw = "||".join("" if part is None else str(part) for part in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:length]

def normalize_whitespace(text: Any) -> str:
    if text is None or (isinstance(text, float) and pd.isna(text)):
        return ""
    return " ".join(str(text).replace("\xa0", " ").split())

def parse_date(value: Any) -> pd.Timestamp | pd.NaT:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return pd.NaT
    if isinstance(value, pd.Timestamp):
        return value
    if isinstance(value, (datetime, date)):
        return pd.Timestamp(value)
    text = str(value).strip()
    if not text:
        return pd.NaT
    return pd.to_datetime(text, errors="coerce", utc=False)
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

DATE = re.compile(r"\d{1,2}/\d{1,2}/\d{4}")

RATING = re.compile(r"([0-5](?:\.\d+)?)\s*/\s*5")

LIKES = re.compile(r"What do you like best about (.+)\?")

DISLIKES = re.compile(r"What do you dislike about (.+)\?")

BENEFITS = re.compile(r"What problems is (.+) solving and how is that benefiting you\?")

HOSTED = "Review collected by and hosted on G2.com."

def paragraphs(path):
    with ZipFile(path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    result = []
    for p in root.findall(".//w:p", NS):
        text = normalize_whitespace("".join(t.text or "" for t in p.findall(".//w:t", NS)))
        if text:
            style = p.find("w:pPr/w:pStyle", NS)
            result.append((style.get(f"{{{NS['w']}}}val", "") if style is not None else "", text))
    return result

def parse_paragraphs(rows, collection_date=None):
    sections = []
    for index, (style, text) in enumerate(rows):
        if style.lower().startswith("heading"):
            sections.append((text, []))
        elif sections:
            sections[-1][1].append((index, text))
    records, audit = [], []
    lookup = {p["product"].casefold(): p for p in load_products()}
    for heading, lines in sections:
        ratings = [i for i, (_, text) in enumerate(lines) if RATING.fullmatch(text)]
        likes_count = sum(bool(LIKES.fullmatch(t)) for _, t in lines)
        if len(ratings) != likes_count:
            raise ValueError(f"{heading}: {len(ratings)} ratings but {likes_count} review-start questions")
        for number, start in enumerate(ratings):
            stop = ratings[number + 1] if number + 1 < len(ratings) else len(lines)
            previous = ratings[number - 1] + 1 if number else 0
            header = lines[previous:start]
            dates = [(i, text) for i, text in header if DATE.fullmatch(text)]
            review_date = dates[-1][1] if dates else ""
            title = lines[start - 1][1].strip('"“”') if start else ""
            if DATE.fullmatch(title):
                title = ""
            bodies = {"Likes": [], "Dislikes": [], "Benefits": []}
            current = None
            product = None
            seen = []
            for pos, text in lines[start + 1:stop]:
                question = next(((name, pattern.fullmatch(text)) for name, pattern in
                                 [("Likes", LIKES), ("Dislikes", DISLIKES), ("Benefits", BENEFITS)]
                                 if pattern.fullmatch(text)), None)
                if question:
                    current, match = question
                    question_product = match.group(1)
                    if product is not None and product.casefold() != question_product.casefold():
                        raise ValueError(f"Mixed products in review at paragraph {pos}")
                    product = question_product
                    seen.append(current)
                elif text == HOSTED or text.startswith(("Show More", "Show Less", "Source:", "Validated Reviewer", "Current User", "Incentivized")) or DATE.fullmatch(text):
                    current = None
                elif current:
                    bodies[current].append(text)
            if seen.count("Likes") != 1 or not bodies["Likes"]:
                raise ValueError(f"Incomplete review in {heading}, rating paragraph {lines[start][0]}")
            cfg = lookup.get(product.casefold())
            if cfg is None:
                raise ValueError(f"Unconfigured product: {product}")
            # Use only the two fields used by the earlier analysis. Keep the
            # additional benefits text in the audit for possible later analysis.
            likes = normalize_whitespace(" ".join(bodies["Likes"]))
            dislikes = normalize_whitespace(" ".join(bodies["Dislikes"]))
            review_text = " | ".join(f"{name}: {value}" for name, value in [("Likes", likes), ("Dislikes", dislikes)] if value)
            rid = stable_hash("G2 manual DOCX", cfg["product"], review_date, title, likes, dislikes)
            records.append({"review_id": rid, "company": cfg["company"], "product": cfg["product"],
                            "source": "G2", "review_date": review_date,
                            "rating": float(RATING.fullmatch(lines[start][1]).group(1)),
                            "review_title": title, "review_text": review_text,
                            "review_url": "", "ai_relevant": "", "relevance_reason": "",
                            "collection_date": collection_date or today_iso()})
            audit.append({"review_id": rid, "heading": heading, "product": cfg["product"],
                          "rating_paragraph": lines[start][0] + 1, "missing_date": not bool(review_date),
                          "missing_dislikes": not bool(dislikes), "likes": likes, "dislikes": dislikes,
                          "benefits_not_analysed": " ".join(bodies["Benefits"])})
    if not records:
        raise ValueError("No reviews found in the document")
    return pd.DataFrame(records), pd.DataFrame(audit)
def _phrase_pattern(phrase: str) -> str:
    return r"\b" + re.escape(phrase.lower()).replace(r"\ ", r"\s+") + r"\b"

class LexiconSentimentAnalyzer:
    def __init__(self, settings: dict[str, Any] | None = None):
        self.settings = settings or load_settings()
        sentiment = self.settings.get("sentiment", {})
        self.positive_words = [str(word).lower() for word in sentiment.get("positive_words", [])]
        self.negative_words = [str(word).lower() for word in sentiment.get("negative_words", [])]
        self.negations = set(str(word).lower() for word in sentiment.get("negations", []))
        self.intensifiers = set(str(word).lower() for word in sentiment.get("intensifiers", []))
        self.positive_threshold = float(sentiment.get("positive_threshold", 0.08))
        self.negative_threshold = float(sentiment.get("negative_threshold", -0.08))

    def score(self, text: str) -> tuple[float, str, float]:
        text = normalize_whitespace(text).lower()
        if not text:
            return 0.0, "Neutral", 0.0
        tokens = re.findall(r"[a-zA-Z][a-zA-Z'-]*", text)
        token_scores: list[float] = []

        for phrase in self.positive_words:
            if " " in phrase:
                token_scores.extend([1.2] * len(re.findall(_phrase_pattern(phrase), text)))
        for phrase in self.negative_words:
            if " " in phrase:
                token_scores.extend([-1.2] * len(re.findall(_phrase_pattern(phrase), text)))

        for idx, token in enumerate(tokens):
            base = 0.0
            if token in self.positive_words:
                base = 1.0
            elif token in self.negative_words:
                base = -1.0
            if base == 0.0:
                continue
            window = tokens[max(0, idx - 3) : idx]
            if any(word in self.negations for word in window):
                base *= -1.0
            if any(word in self.intensifiers for word in window):
                base *= 1.25
            token_scores.append(base)

        if not token_scores:
            return 0.0, "Neutral", 0.25
        score = float(np.tanh(sum(token_scores) / max(np.sqrt(len(tokens)), 1.0)))
        if score >= self.positive_threshold:
            label = "Positive"
        elif score <= self.negative_threshold:
            label = "Negative"
        else:
            label = "Neutral"
        confidence = min(1.0, abs(score) + 0.35)
        return score, label, confidence
TAXONOMY = [
 ("Ease of use & onboarding", "Usability, navigation, setup and learning; excludes generic 'use' alone.",
  r"\beas(?:y|ier|iest|ily)\b|\bintuitive\b|\buser[ -]friendly\b|\blearning curve\b|\bonboarding\b|\bsetup\b|\bset up\b|\bbeginner\w*\b|\busability\b|\binterface\b|\bnavigat\w*\b|\bcomplicated\b|\bconfus\w*\b|\bsimple to\b|\bease of\b|\bUI(?:/UX)?\b"),
 ("Output quality & consistency", "Visual/output quality, realism, resolution, artifacts and consistency; not image/video mentions alone.",
  r"\bquality\b|\bresolution\b|\brealistic\b|\bphotorealis\w*\b|\bartifacts?\b|\bblurr\w*\b|\bpixelat\w*\b|\bdistort\w*\b|\bconsisten\w*\b|\binconsisten\w*\b|\btext rendering\b|\b(?:image|video|output|result)s? (?:look|looks|is|are|feel|feels)\b|\banatom\w*\b|\b(?:facial|fine|visual) details?\b|\bgeneric\b"),
 ("Editing control & prompts", "Editing features, local corrections, customisation and prompt adherence; no bare 'image' match.",
  r"\bedit(?:ing|s|able|or)?\b|\bcontrol\b|\bcustomi[sz]\w*\b|\bfine[ -]tun\w*\b|\bgenerative fill\b|\binpaint\w*\b|\boutpaint\w*\b|\bretouch\w*\b|\bbackground remov\w*\b|\bremov\w* backgrounds?\b|\b(?:object|background) (?:removal|replacement)\b|\bprompts?\b|\brefin\w*\b|\bprecis\w*\b|\badjust\w*\b"),
 ("Pricing & subscription value", "Prices, paid plans, affordability, billing and value; credit-specific costs assigned to credits unless plans are explicit.",
  r"\bpric\w*\b|\bexpensive\b|\bafford\w*\b|\bcost(?:s|ly)?\b|\bsubscription\w*\b|\bbilling\b|\bfees?\b|\bpaid\b|\bpay(?:ing|ment|ments)?\b|\bpremium\b|\brefund\w*\b|\bcharges?\b|\bcharged\b|\bvalue for money\b|\bbudget\b|\bfree (?:plan|tier|version)\b|\b(?:monthly|annual) plans?\b|\bwast\w* money\b"),
 ("AI credits & usage limits", "Generation credits/tokens, quotas and generation caps; not generic limitations.",
  r"\bcredits?\b|\btokens?\b|\bquotas?\b|\bgeneration limits?\b|\b(?:daily|monthly|usage|download) (?:limit|cap)s?\b|\blimited generations?\b|\b(?:run|running|ran) out of\b"),
 ("Speed & reliability", "Runtime speed, lag, loading, crashes, stability and errors; productivity savings are separate.",
  r"\bslow\w*\b|\blag(?:s|gy|ging)?\b|\bspeed\b|\bfast(?:er|est)?\b|\bquick(?:ly|er)?\b|\bload(?:s|ing)?\b|\bcrash\w*\b|\bfreez\w*\b|\bfroze\b|\bbugs?\b|\bbuggy\b|\breliab\w*\b|\bunreliab\w*\b|\bstabil\w*\b|\bdowntime\b|\bglitch\w*\b|\bperformance\b|\bqueues?\b|\berrors?\b|\bwait(?:ing)?\b"),
 ("Workflow & integrations", "Explicit integrations, interoperability, importing/exporting and workflow; names alone do not trigger.",
  r"\bintegrat\w*\b|\bworkflow\w*\b|\bplugins?\b|\bAPI\b|\bexport\w*\b|\bimport\w*\b|\bcompatib\w*\b|\bconnect\w*\b|\bwork(?:s|ing)? (?:with|across) (?:other|Adobe|Photoshop|Illustrator|Canva)\b"),
 ("Customer support & accounts", "Service responses, assistance and account/access issues; generic feature support is not sufficient.",
  r"\bcustomer (?:support|service|care)\b|\bsupport (?:team|staff|response|is|was|has|does|tickets?)\b|\b(?:contact|contacted|contacting|reach|reached|responsive|unresponsive|poor|no|technical) support\b|\b(?:no|nobody|never) (?:one )?(?:repl\w*|respond\w*)\b|\blog[ -]?in\w*\b|\bsign[ -]?in\b|\baccount (?:access|suspend\w*|bann\w*|block\w*|delet\w*)\b|\bno support\b|\bSupport is\b"),
 ("Commercial rights & licensing", "Commercial-use permission, copyright, IP and licensing; generic safe/license mentions require rights context.",
  r"\bcopyright\w*\b|\blicens\w*\b|\bcommercial[ -](?:use|rights)\b|\bintellectual property\b|\broyalty[ -]free\b|\busage rights\b"),
 ("Creative assets & capabilities", "Templates, asset libraries, ideation and breadth of creative functionality; not product names or generic 'feature' alone.",
  r"\btemplates?\b|\bassets?\b|\blibrar\w*\b|\bcreativ\w*\b|\binspir\w*\b|\bideas?\b|\bideation\b|\bdesign (?:options|systems)\b|\bwireframes?\b|\bmockups?\b|\bprototyp\w*\b|\bvariety\b|\bversatil\w*\b"),
 ("Time savings & productivity", "Explicit saved time/effort, automation and productivity; not fast rendering alone.",
  r"\bsav\w* (?:\w+\s+){0,4}(?:time|hours?|effort|days?)\b|\btime[ -]sav\w*\b|\bproductiv\w*\b|\befficien\w*\b|\bautomat\w*\b|\btime.consuming\b|\bspeed(?:s|ing)? up (?:my|our|the) work\b"),
 ("Collaboration & sharing", "Multi-person collaboration, shared designs, feedback and handoff; generic team membership is insufficient.",
  r"\bcollaborat\w*\b|\bteamwork\b|\bshar(?:e|ed|ing) (?:\w+\s+){0,3}(?:design|file|project|feedback)\w*\b|\breal[ -]time (?:edit|work|collaborat)\w*\b|\bhandoff\b|\bversion (?:control|conflict)\w*\b|\bmultiple (?:users|team members)\b"),
 ("Web publishing & management", "Website-specific hosting, CMS, publishing, domains and SEO; retained to expose product-scope differences.",
  r"\bCMS\b|\bhosting\b|\bdomains?\b|\bSEO\b|\bpublish\w*\b|\bwebsite\w*\b|\bweb sites?\b|\bweb design\b|\bblog\b|\bURLs?\b|\blocali[sz]\w*\b"),
]

PATTERNS = [(name, re.compile(pattern, re.I)) for name, _, pattern in TAXONOMY]

TEMPLATE_MARKERS = ["Focus on the features, benefits", "Suggestions Be specific and mention", "Share any unexpected benefits you've discovered"]

REQUEST = re.compile(r"\b(?:wish|hope)\b|\b(?:would|could) (?:be|like|love|appreciate|benefit|improve|use|have)\b|\bit would\b|\b(?:recommend|suggest)(?:ing)? (?:adding|improving|that)\b|\bshould (?:be|have|offer|allow|work)\b|\b(?:want|need)s? (?:more|better|to be)\b", re.I)

def topics(text):
    result = {name: sorted(set(m.group(0) for m in pattern.finditer(text))) for name, pattern in PATTERNS if pattern.search(text)}
    if re.search(r"\b(?:hard|difficult) to (?:use|learn)\b",text,re.I):
        result.setdefault("Ease of use & onboarding",[]).append("hard/difficult to use/learn")
    # Explicit hierarchical rule: costs of credits belong to usage limits rather than double counting price.
    if "AI credits & usage limits" in result and "Pricing & subscription value" in result:
        if not re.search(r"\b(?:subscription|plan|billing|fee|annual|monthly|refund)\w*\b", text, re.I):
            result.pop("Pricing & subscription value")
    # 'costs time' is not a financial-price observation unless money/pricing is explicit.
    if "Pricing & subscription value" in result and re.search(r"\bcost\w* (?:\w+ )?(?:time|effort)\b", text, re.I):
        if not re.search(r"\b(?:pric\w*|money|paid|subscription|expensive|dollars?|euros?)\b|[$€]", text, re.I):
            result.pop("Pricing & subscription value")
    return result

def spans(text, start, end, boundary):
    cursor = start
    for match in re.finditer(boundary, text[start:end], re.I):
        a, b = cursor, start + match.start()
        while a < b and text[a].isspace(): a += 1
        while b > a and text[b-1].isspace(): b -= 1
        if a < b: yield a, b
        cursor = start + match.end()
    a, b = cursor, end
    while a < b and text[a].isspace(): a += 1
    while b > a and text[b-1].isspace(): b -= 1
    if a < b: yield a, b

def section_spans(text):
    if text.startswith("Likes:"):
        marker = re.search(r"\s*\|\s*Dislikes:\s*", text)
        if marker:
            return [("Likes", len("Likes:"), marker.start()), ("Dislikes", marker.end(), len(text))]
        return [("Likes", len("Likes:"), len(text))]
    if text.startswith("Dislikes:"):
        return [("Dislikes", len("Dislikes:"), len(text))]
    return [("Unsectioned", 0, len(text))]

def build_evidence(reviews):
    rows = []
    for review in reviews.itertuples():
        text = review.review_text
        for section, ss, se in section_spans(text):
            section_text = text[ss:se]
            contaminated = any(marker.lower() in section_text.lower() for marker in TEMPLATE_MARKERS)
            for sentence_start, sentence_end in spans(text, ss, se, r"(?<=[.!?])\s+(?=[A-Z0-9\"“])"):
                sentence = text[sentence_start:sentence_end]
                boundary = r";\s*|\s+\b(?:but|however|although|whereas)\b[,:]?\s*"
                if "not only" in sentence.lower(): boundary = r";\s*"
                for start, end in spans(text, sentence_start, sentence_end, boundary):
                    clause = text[start:end]
                    matched = topics(clause)
                    model_text = clause
                    reason = "eligible"
                    if len(re.findall(r"\b\w+\b", clause)) < 4:
                        parent_topics = topics(sentence)
                        if len(matched) == 1 and set(parent_topics) == set(matched):
                            model_text = sentence
                        else:
                            reason = "insufficient_context"
                    if contaminated: reason = "copied_annotation_instructions"
                    elif not matched: reason = "no_taxonomy_match"
                    elif len(matched) > 1: reason = "multiple_aspects_unresolved"
                    elif REQUEST.search(clause): reason = "hypothetical_or_feature_request"
                    elif "Workflow & integrations" in matched and re.search(r"\bintegrat\w*.*\b(?:image|background|scene)\b",clause,re.I) and not re.search(r"\b(?:workflow|app|software|product|Photoshop|Illustrator|API|plugin)\w*\b",clause,re.I):
                        reason = "visual_integration_not_interoperability"
                    evidence_id = hashlib.sha256(f"{review.review_id}:{start}:{end}".encode()).hexdigest()[:20]
                    rows.append({"evidence_id": evidence_id, "review_id": review.review_id, "product": review.product,
                                 "section": section, "char_start": start, "char_end": end,
                                 "evidence_text": clause, "sentence_context": sentence, "model_input": model_text,
                                 "candidate_topics": json.dumps(list(matched)), "matched_terms": json.dumps(matched),
                                 "candidate_topic_count": len(matched), "eligibility": reason,
                                 "feature_request_flag": bool(REQUEST.search(clause)),
                                 "topic": next(iter(matched)) if len(matched) == 1 else "",
                                 "source_quality_flag": ""})
    return pd.DataFrame(rows)

def parse_and_clean(path):
    records,audit=parse_paragraphs(paragraphs(path),collection_date='2026-10-21')
    d=records.copy()
    d['review_date']=d.review_date.map(parse_date)
    d['review_text']=d.review_text.map(normalize_whitespace)
    d['duplicate_key']=d.apply(lambda r:stable_hash(r.source,r['product'],r.review_date,r.review_text),axis=1)
    d=d.sort_values(['product','review_date','review_id'],na_position='last')
    clean=d.drop_duplicates('duplicate_key',keep='first').reset_index(drop=True)
    return records,clean,audit

def retained_evidence(reviews):
    candidates=build_evidence(reviews)
    eligible=candidates.loc[candidates.eligibility.eq('eligible')].copy()
    eligible['dedup_key']=eligible.evidence_text.str.casefold().str.replace(r'\s+',' ',regex=True).str.strip()
    eligible=eligible.drop_duplicates(['review_id','topic','dedup_key']).reset_index(drop=True)
    return candidates,eligible

def validate_frozen(reviews, predictions, aspects):
    assert reviews.review_id.is_unique and predictions.review_id.is_unique
    check=reviews.merge(predictions,on='review_id',validate='one_to_one',suffixes=('_raw','_pred'))
    assert len(check)==len(reviews)==len(predictions)==819
    assert check.review_text_raw.eq(check.review_text_pred).all()
    assert check.product_raw.eq(check.product_pred).all()
    texts=reviews.set_index('review_id').review_text
    assert all(texts.loc[r.review_id][r.char_start:r.char_end]==r.evidence_text for r in aspects.itertuples())
    assert aspects.sentiment.eq(aspects.roberta).all()
    return {'unique_reviews':len(reviews),'products':reviews['product'].nunique(),'aspect_rows':len(aspects),'reviews_with_evidence':aspects.review_id.nunique(),'exact_evidence_spans':True}

def roberta_predict(texts, cache_dir=None):
    """Explicit optional CPU inference. Downloads the immutable revision if absent."""
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
    from huggingface_hub import snapshot_download
    torch.manual_seed(42);torch.set_num_threads(4)
    cache=Path(cache_dir) if cache_dir else ROOT/'.cache/models'
    snapshot=snapshot_download(MODEL_ID,revision=REVISION,cache_dir=str(cache))
    tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
    model=AutoModelForSequenceClassification.from_pretrained(snapshot,local_files_only=True).to('cpu').eval()
    labels=[model.config.id2label[i].title() for i in range(3)]
    assert sorted(labels)==sorted(CLASSES)
    capacity=min(int(tokenizer.model_max_length),int(model.config.max_position_embeddings)-2,512)-2
    assert capacity==510
    windows=[];lengths=[];counts=[]
    for i,text in enumerate(texts):
        ids=tokenizer.encode(text,add_special_tokens=False,truncation=False)
        pieces=[ids[j:j+capacity] for j in range(0,len(ids),capacity)] or [[]]
        lengths.append(len(ids));counts.append(len(pieces))
        windows.extend((i,max(len(piece),1),[tokenizer.bos_token_id]+piece+[tokenizer.eos_token_id]) for piece in pieces)
    order=sorted(range(len(windows)),key=lambda i:len(windows[i][2]))
    probabilities=np.zeros((len(texts),3));weights=np.zeros(len(texts))
    with torch.inference_mode():
        for start in range(0,len(order),8):
            selected=[windows[i] for i in order[start:start+8]]
            batch=tokenizer.pad({'input_ids':[w[2] for w in selected]},padding=True,return_tensors='pt')
            probs=torch.softmax(model(**batch).logits,dim=-1).cpu().numpy()
            for (i,weight,_),prob in zip(selected,probs):probabilities[i]+=prob*weight;weights[i]+=weight
            if start%160==0:print(f'RoBERTa windows: {min(start+8,len(order))}/{len(order)}',flush=True)
    probabilities/=weights[:,None]
    assert np.allclose(probabilities.sum(axis=1),1,atol=1e-6)
    return pd.DataFrame([{'roberta':labels[int(p.argmax())],'roberta_confidence':float(p.max()),'roberta_token_count':lengths[i],'roberta_windows':counts[i],**{f'roberta_probability_{label.lower()}':float(value) for label,value in zip(labels,p)}} for i,p in enumerate(probabilities)])
