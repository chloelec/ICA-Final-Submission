# Final ETH Submission — Industry and Competitive Analysis

This folder is self-contained. It contains strategic clustering, G2 sentiment
analysis and dictionary-based SEC filing analysis. No other ICA project folder is needed.

## Read and run

1. **01_Strategic_Clustering.ipynb** — 22 firms; four equally weighted variables;
   fixed custom three groups (8/6/8), with the k=2 hierarchy as a benchmark.
2. **02_G2_Sentiment_Analysis.ipynb** — 819 reviews across nine products;
   RoBERTa overall sentiment and 1,878 retained aspect-evidence rows.
3. **03_SEC_Filings_Analysis.ipynb** — extraction and dictionary tagging using
   `helpers/sec_filings.py`.

Keep the whole folder together. Saved notebook outputs and `results/` can be
read without execution. To regenerate results, install Python 3.14, open a
terminal inside this folder (beside this README), and follow the commands below.
Internet is needed for installation; default notebook execution uses local files.

**macOS / Linux**

```sh
python3.14 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt notebook
.venv/bin/python -m ipykernel install --sys-prefix --name final-eth --display-name "Python (Final ETH)"
.venv/bin/jupyter notebook
```

**Windows PowerShell**

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt notebook
.\.venv\Scripts\python.exe -m ipykernel install --sys-prefix --name final-eth --display-name "Python (Final ETH)"
.\.venv\Scripts\jupyter.exe notebook
```

Open each notebook, select **Python (Final ETH)**, restart the kernel and run
all cells. Each notebook is independent. Use this folder as the working directory.
In PyCharm, select the local `.venv` interpreter. If a module is missing, check
that the selected kernel is the environment where the requirements were installed.

Leave notebook 02's optional inference flag set to `False` for the default run.
It verifies and aggregates saved predictions rather than rerunning RoBERTa.
Optional inference requires `requirements-inference.txt` and a model download.
Notebook 03 uses dictionary rules and requires no transformer model.

## Folder contents

| Path | Purpose |
| --- | --- |
| `data/raw/` | Company workbook, original G2 review document, and SEC HTML filings in `sec/` |
| `data/sec_manifest.csv` | SEC filing selection and local input paths |
| `data/processed/` | Reviews and saved review/aspect predictions |
| `data/validation/` | G2 labels, evaluation records, and 30 reviewed aspect examples with scores |
| `helpers/` | One helper module for each analysis: `clustering.py`, `reviews.py`, `sec_filings.py` |
| `config/` | Custom groups, review settings, model versions and coding decisions |
| `results/` | Regenerated figures, workbooks and verification records |

The notebooks calculate results from the included `data/`, `config/` and `helpers/`
files.
The saved G2 predictions in `data/processed/` are required inputs for the default run.
Runtime caches, editor settings and virtual environments are not submission inputs.

## SEC workflow and scope

Notebook 03 imports `helpers/sec_filings.py`, which combines the source schema,
dictionaries, extraction and tagging functions. `data/sec_manifest.csv` determines
inclusion. Available
manifest-listed inputs cover **Adobe FY2019 and FY2025**. Other listed companies'
files are absent and are explicitly reported in the coverage table. Adobe FY2022
is present in `data/raw/sec`, but is not listed in the manifest;
it is preserved without adding it to the analysis. Manifest source URLs are blank.

The extractor retains Business, Risk Factors and MD&A paragraphs. The tagger
summarizes Risk Factors alone and Business plus Risk Factors. Force rates count
matched sentence segments per 1,000 words, with an additional dependency-word
requirement for supplier matches. GenAI and broader-AI flags count paragraphs.
Placebo-rate columns count keyword occurrences. The notebook performs explicit
structural and rate checks.

SEC paragraphs, tagged data, summary tables and figures are regenerated from the
included HTML filings and written to `results/filings`.
Notebook 03 checks that its helper and input files remain unchanged during execution.

## Results and verification

- Notebook 01 writes clustering workbooks, figures and `01_verification.json`.
- Notebook 02 writes sentiment workbooks, figures and `02_verification.json`.
- Notebook 03 writes `results/filings/filings_results.xlsx`, paragraph/tag/summary
  CSVs, two figures and `03_verification.json`.

Successful runs display `PASS` checks. Rerunning replaces generated results.
The input files remain unchanged.

## Interpretation limits

- Ordinal codes are treated as equally spaced in the clustering distances.
- G2 reviews cover seven of the 22 selected firms; Adobe reviews concern Firefly.
  Magnific reviews are mapped to Freepik / Magnific following an attribution check.
- Sentiment model comparison uses 49 labelled development reviews, not a held-out
  test. The first 30 aspect examples were validated with help from Claude: 23/30
  correct topics (76.7%) and 18/30 sentiment agreements (60.0%). These scores describe
  that reviewed sample.
- SEC findings describe dictionary matches in management disclosures, not causal
  effects, topic-model accuracy or measured competitive-force intensity. Missing
  source URLs and missing manifest-listed filings are reported rather than inferred.
