# Analytical decisions

Clustering: exactly the 22 identities in custom_groups.csv. Four equal-weight inputs:
Product categories (breadth, C), Value-chain coverage (D), GENAI Importance (E),
Pricing model (F), read by header from row 4 of the original workbook.
Numeric/ordinal differences are divided by observed ranges within these 22 firms;
pricing contributes 0 for equal categories and 1 otherwise. No imputation.
Importance codes are treated as equally spaced ordinal values.
Average linkage with the four-variable Gower matrix provides the hierarchy.
The highest silhouette among tested cuts k=2–7 is at k=2 (0.572216).
This benchmark cut is marked on the dendrogram; labels show custom groups.
The custom 8/6/8 memberships are fixed theory-guided assignments, never a k=3 tree cut.
They retain a separate usage-oriented category for strategic interpretation.
All clustering figures and generated group results use these three memberships
and only the four inputs above (custom-group silhouette 0.568146).
MDS seed 42, eight random initializations, max_iter 1000, eps 1e-7.

Reviews: 829 document blocks; 819 unique cleaned Likes/Dislikes reviews.
Benefits answers are preserved in the source audit but excluded from sentiment text.
AI-image relevance flags do not select this final population. Models use text only,
not ratings. Local IDs and paragraph references replace unavailable original G2 IDs/URLs.
Thirteen researcher-defined aspect rules are in helpers/reviews.py; they are not NMF
topics. Count each review once per topic/polarity; denominator is all reviews in its
product/group. Positive and negative counts may overlap. Neutral remains a third label.
The 676 cluster-linked reviews exclude Framer (100) and Kittl (43), not reassigned.
Magnific reviews are mapped to Freepik / Magnific following a product-attribution
check. Adobe observations concern Firefly only.
Overall model evaluation uses 49 previously inspected development labels. A separate
sample of 30 aspect examples was validated with help from Claude: topic correctness
was 23/30 (76.7%) and sentiment agreement was 18/30 (60.0%). These scores describe
the reviewed sample. Labels and scores are included in data/validation/review_validation.xlsx;
saved model predictions are in data/processed/.


SEC filings: notebook 03 uses helpers/sec_filings.py, consolidated from the schema,
dictionaries, extraction and tagging functions supplied in ica_filings. Analytical
rules are unchanged. data/sec_manifest.csv retains the original inclusion list
with paths updated to data/raw/sec. Missing files are reported explicitly. The
unlisted FY2022 file is preserved but not added to the analysis. Paragraphs,
tagged data, summary tables and figures are regenerated from the included HTML
filings in results/filings.
